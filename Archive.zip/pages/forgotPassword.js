import React, { Component } from 'react';
import ForgotPass from "../src/containers/forgotpassword";

class ForgotPassword extends Component {
  render() {
    return (
      <div>
        <ForgotPass />
      </div>
    )
  }
}


export default ForgotPassword;